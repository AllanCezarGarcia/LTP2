﻿// See https://aka.ms/new-console-template for more information
using System.Security.AccessControl;

Console.WriteLine("Hello, World!");
Console.WriteLine("Qual seu nome?");
string nome = Console.ReadLine();
Console.WriteLine("Seja bemvindo(a) " + nome);
string cidade = "Pinheiral";
Console.WriteLine($"Eu não gosto de {cidade}");
int idade = 17;
Console.WriteLine($"Olá {nome}, você tem {idade} anos!");
float altura = 1.76f, peso = 83.2f;
double nanoAltura = altura * 0.000000001;
Console.WriteLine($"A sua altura é {altura}m");
Console.WriteLine($"Se vc fosse o homem formiga teria a altura {nanoAltura} nm");
Console.WriteLine($"O peso informado foi: {peso}kg");
Console.WriteLine(cidade + idade);